let api = "https://dev.halsoft.net/v1/"
//let api = "http://api.ymjq.com/v1/"
//let api = "http://192.168.0.155/yimin/api/web/v1/"
module.exports = {
  api: api
}